import { useState } from 'react';
import { FileText, Download, Eye, Edit, Plus, Search, Filter } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';

type ProposalStatus = 'Draft' | 'In Review' | 'Approved' | 'Sent' | 'Signed' | 'Completed';

const statusConfig = {
  'Draft': { color: 'bg-[#A0A0A0] text-white', step: 1 },
  'In Review': { color: 'bg-[#F59E0B] text-white', step: 2 },
  'Approved': { color: 'bg-[#10B981] text-white', step: 3 },
  'Sent': { color: 'bg-[#3B82F6] text-white', step: 4 },
  'Signed': { color: 'bg-[#10B981] text-white', step: 5 },
  'Completed': { color: 'bg-[#10B981] text-white', step: 6 }
};

const proposalsData: Array<{
  id: string;
  client: string;
  status: ProposalStatus;
  value: string;
  createdDate: string;
  template: string;
}> = [
  {
    id: 'PROP-2024-089',
    client: 'Acme Corporation',
    status: 'Approved',
    value: '$125,000',
    createdDate: 'Jan 15, 2024',
    template: 'Enterprise Services'
  },
  {
    id: 'PROP-2024-088',
    client: 'TechFlow Solutions',
    status: 'In Review',
    value: '$89,500',
    createdDate: 'Jan 14, 2024',
    template: 'Software Implementation'
  },
  {
    id: 'PROP-2024-087',
    client: 'Global Enterprises',
    status: 'Sent',
    value: '$245,000',
    createdDate: 'Jan 12, 2024',
    template: 'Digital Transformation'
  },
  {
    id: 'PROP-2024-086',
    client: 'Innovation Labs',
    status: 'Draft',
    value: '$67,800',
    createdDate: 'Jan 10, 2024',
    template: 'Consulting Services'
  },
  {
    id: 'PROP-2024-085',
    client: 'Digital Dynamics',
    status: 'Signed',
    value: '$156,000',
    createdDate: 'Jan 08, 2024',
    template: 'Cloud Migration'
  },
];

const lifecycleSteps = ['Draft', 'In Review', 'Approved', 'Sent', 'Signed', 'Completed'];

function LifecycleTracker({ currentStatus }: { currentStatus: ProposalStatus }) {
  const currentStep = statusConfig[currentStatus].step;

  return (
    <div className="space-y-4">
      <h3 className="font-medium text-[#1A1A1A]">Proposal Lifecycle</h3>
      <div className="flex items-center justify-between">
        {lifecycleSteps.map((step, index) => {
          const stepNumber = index + 1;
          const isCompleted = stepNumber < currentStep;
          const isCurrent = stepNumber === currentStep;
          
          return (
            <div key={step} className="flex flex-col items-center flex-1">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                isCompleted ? 'bg-[#10B981] text-white' :
                isCurrent ? 'bg-[#3B82F6] text-white' :
                'bg-[#E5E5E5] text-[#A0A0A0]'
              }`}>
                {stepNumber}
              </div>
              <span className={`text-xs mt-1 text-center ${
                isCompleted || isCurrent ? 'text-[#1A1A1A] font-medium' : 'text-[#A0A0A0]'
              }`}>
                {step}
              </span>
              {index < lifecycleSteps.length - 1 && (
                <div className={`w-full h-0.5 mt-2 ${
                  isCompleted ? 'bg-[#10B981]' : 'bg-[#E5E5E5]'
                }`} />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function ProposalsView() {
  const [selectedProposal, setSelectedProposal] = useState<ProposalStatus>('Draft');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#1A1A1A]">Generate Proposal</h1>
          <p className="text-[#6B7280] mt-1">Create and manage your proposals</p>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Form Section */}
        <Card className="border border-[#E0E0E0] shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-medium text-[#1A1A1A]">Proposal Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="quoteId">Quote ID</Label>
              <Input 
                id="quoteId"
                placeholder="PROP-2024-090"
                className="bg-gray-50"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="clientName">Client Name</Label>
              <Input 
                id="clientName"
                placeholder="Enter client name..."
                className="bg-gray-50"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="proposalType">Proposal Type</Label>
              <Select>
                <SelectTrigger className="bg-gray-50">
                  <SelectValue placeholder="Select proposal type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="enterprise">Enterprise Services</SelectItem>
                  <SelectItem value="software">Software Implementation</SelectItem>
                  <SelectItem value="consulting">Consulting Services</SelectItem>
                  <SelectItem value="cloud">Cloud Migration</SelectItem>
                  <SelectItem value="digital">Digital Transformation</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="template">Template</Label>
              <Select>
                <SelectTrigger className="bg-gray-50">
                  <SelectValue placeholder="Select template" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="standard">Standard Services Template</SelectItem>
                  <SelectItem value="enterprise">Enterprise Template</SelectItem>
                  <SelectItem value="consulting">Consulting Template</SelectItem>
                  <SelectItem value="technical">Technical Implementation</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="estimatedValue">Estimated Value</Label>
              <Input 
                id="estimatedValue"
                placeholder="$0.00"
                className="bg-gray-50"
              />
            </div>

            <Button className="w-full bg-[#10B981] hover:bg-[#0D9F71] text-white">
              <Plus className="h-4 w-4 mr-2" />
              Generate Proposal
            </Button>
          </CardContent>
        </Card>

        {/* Preview Section */}
        <Card className="border border-[#E0E0E0] shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-medium text-[#1A1A1A]">Proposal Preview</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="border-2 border-dashed border-[#E0E0E0] rounded-lg p-8 text-center bg-gray-50">
              <FileText className="h-12 w-12 text-[#A0A0A0] mx-auto mb-3" />
              <p className="text-[#6B7280] mb-2">No proposal generated yet</p>
              <p className="text-sm text-[#A0A0A0]">Fill in the form and click "Generate Proposal" to see preview</p>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" disabled>
                <Eye className="h-4 w-4 mr-2" />
                Preview
              </Button>
              <Button variant="outline" className="flex-1" disabled>
                <Download className="h-4 w-4 mr-2" />
                Download PDF
              </Button>
            </div>

            {/* Lifecycle Tracker */}
            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <LifecycleTracker currentStatus={selectedProposal} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Proposals Table */}
      <Card className="border border-[#E0E0E0] shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-medium text-[#1A1A1A]">Recent Proposals</CardTitle>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#6B7280] h-4 w-4" />
                <Input 
                  placeholder="Search proposals..."
                  className="pl-10 w-64 bg-gray-50"
                />
              </div>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Proposal ID</TableHead>
                <TableHead>Client Name</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Value</TableHead>
                <TableHead>Template</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {proposalsData.map((proposal) => (
                <TableRow key={proposal.id} className="hover:bg-gray-50">
                  <TableCell className="font-medium">{proposal.id}</TableCell>
                  <TableCell>{proposal.client}</TableCell>
                  <TableCell>
                    <Badge className={statusConfig[proposal.status].color}>
                      {proposal.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{proposal.value}</TableCell>
                  <TableCell>{proposal.template}</TableCell>
                  <TableCell>{proposal.createdDate}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-[#6B7280] hover:text-[#10B981] hover:bg-[#E6F4EA]"
                        aria-label={`View proposal ${proposal.id}`}
                        onClick={() => setSelectedProposal(proposal.status)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-[#6B7280] hover:text-[#10B981] hover:bg-[#E6F4EA]"
                        aria-label={`Edit proposal ${proposal.id}`}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}