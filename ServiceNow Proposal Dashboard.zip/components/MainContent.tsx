import { QuoteInputPanel } from './QuoteInputPanel';
import { ProposalPreview } from './ProposalPreview';
import { RecentProposals } from './RecentProposals';

export function MainContent() {
  return (
    <main className="flex-1 p-6 bg-white">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Top Row - Quote Input and Proposal Preview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <QuoteInputPanel />
          <ProposalPreview />
        </div>
        
        {/* Bottom Row - Recent Proposals */}
        <RecentProposals />
      </div>
    </main>
  );
}