import { LayoutDashboard, FileText, Layout, GitBranch, Settings, LucideIcon } from 'lucide-react';
import { Button } from './ui/button';
import { cn } from './ui/utils';

interface NavigationItem {
  icon: LucideIcon;
  label: string;
  key: string;
}

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const navigationItems: NavigationItem[] = [
  { icon: LayoutDashboard, label: 'Dashboard', key: 'dashboard' },
  { icon: FileText, label: 'Proposals', key: 'proposals' },
  { icon: Layout, label: 'Templates', key: 'templates' },
  { icon: GitBranch, label: 'Workflow Designer', key: 'workflow' },
  { icon: Settings, label: 'Settings', key: 'settings' },
];

export function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  return (
    <aside className="w-64 bg-[#F5F5F5] border-r border-[#E0E0E0] shadow-sm">
      <div className="p-4">
        {/* Navigation Items */}
        <nav className="space-y-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.key;
            
            return (
              <Button
                key={item.key}
                variant="ghost"
                onClick={() => onTabChange(item.key)}
                className={cn(
                  "w-full justify-start gap-3 py-3 px-3 hover:bg-white/80 transition-all duration-200",
                  isActive && "bg-white text-[#10B981] shadow-sm hover:bg-white border border-[#10B981]/20",
                  !isActive && "text-[#6B7280] hover:text-[#1A1A1A]"
                )}
              >
                <Icon className={cn(
                  "h-5 w-5 flex-shrink-0",
                  isActive && "text-[#10B981]"
                )} />
                <span className="font-medium">{item.label}</span>
              </Button>
            );
          })}
        </nav>

        {/* Quick Stats */}
        <div className="mt-8 p-4 bg-white rounded-lg shadow-sm border border-[#E0E0E0]">
          <h3 className="font-medium text-[#1A1A1A] mb-3">Quick Stats</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-[#6B7280]">Active Proposals</span>
              <span className="font-medium text-[#10B981]">12</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6B7280]">This Month</span>
              <span className="font-medium">45</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6B7280]">Conversion</span>
              <span className="font-medium text-[#10B981]">78%</span>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}