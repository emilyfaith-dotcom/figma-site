import { Bell, Search, Settings, User } from 'lucide-react';
import { Button } from './ui/button';
import { Avatar, AvatarFallback } from './ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function TopNavigation() {
  return (
    <header className="bg-white border-b border-[#E0E0E0] px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          {/* ServiceNow Logo/Brand */}
          <div className="flex items-center gap-3">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1628760584600-6c31148991e9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZXJ2aWNlbm93JTIwbG9nbyUyMGNvcnBvcmF0ZXxlbnwxfHx8fDE3NTQ1Mzk3MjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="ServiceNow"
              className="w-32 h-8 object-contain"
            />
            <div className="border-l border-gray-300 pl-3">
              <h1 className="text-lg font-semibold text-[#1A1A1A]">Proposal Automation</h1>
              <p className="text-xs text-[#6B7280]">Enterprise Platform</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Search */}
          <div className="relative hidden md:block">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#6B7280] h-4 w-4" />
            <input 
              type="text" 
              placeholder="Search proposals..." 
              className="pl-10 pr-4 py-2 w-80 border border-[#E0E0E0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#10B981] focus:border-transparent bg-gray-50"
            />
          </div>

          {/* Notifications */}
          <Button variant="ghost" size="sm" className="text-[#1A1A1A] hover:bg-gray-50 relative" aria-label="Notifications">
            <Bell className="h-5 w-5" />
            <span className="absolute -top-1 -right-1 bg-[#10B981] text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">3</span>
          </Button>

          {/* Profile Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-2 hover:bg-gray-50">
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="bg-[#10B981] text-white">JD</AvatarFallback>
                </Avatar>
                <span className="hidden md:block text-[#1A1A1A]">John Doe</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem>
                <User className="mr-2 h-4 w-4" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </DropdownMenuItem>
              <DropdownMenuItem>
                Sign out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}