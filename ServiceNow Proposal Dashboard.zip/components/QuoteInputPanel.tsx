import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

export function QuoteInputPanel() {
  return (
    <Card className="bg-white shadow-sm border border-gray-200 rounded-lg">
      <CardHeader className="pb-4">
        <CardTitle className="text-[#1A1A1A] font-medium">Generate Proposal</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="quote-id" className="text-[#1A1A1A] font-medium">Quote ID</Label>
          <Input 
            id="quote-id" 
            placeholder="Enter quote ID" 
            className="bg-[#F3F3F5] border-gray-200 text-[#1A1A1A]"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="client-name" className="text-[#1A1A1A] font-medium">Client Name</Label>
          <Input 
            id="client-name" 
            placeholder="Enter client name" 
            className="bg-[#F3F3F5] border-gray-200 text-[#1A1A1A]"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="proposal-type" className="text-[#1A1A1A] font-medium">Proposal Type</Label>
          <Select>
            <SelectTrigger className="bg-[#F3F3F5] border-gray-200 text-[#1A1A1A]">
              <SelectValue placeholder="Select proposal type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="implementation">Implementation</SelectItem>
              <SelectItem value="consulting">Consulting</SelectItem>
              <SelectItem value="maintenance">Maintenance</SelectItem>
              <SelectItem value="custom">Custom Development</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="template" className="text-[#1A1A1A] font-medium">Template</Label>
          <Select>
            <SelectTrigger className="bg-[#F3F3F5] border-gray-200 text-[#1A1A1A]">
              <SelectValue placeholder="Select template" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="standard">Standard Template</SelectItem>
              <SelectItem value="enterprise">Enterprise Template</SelectItem>
              <SelectItem value="technical">Technical Template</SelectItem>
              <SelectItem value="executive">Executive Summary</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <Button className="w-full bg-[#0A9D58] hover:bg-[#089648] text-white font-medium rounded-lg mt-6">
          Generate Proposal
        </Button>
      </CardContent>
    </Card>
  );
}