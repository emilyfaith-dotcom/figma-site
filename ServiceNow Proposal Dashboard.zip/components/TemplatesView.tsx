import { useState } from 'react';
import { Plus, Search, Edit, Trash2, Copy, FileText, Clock, User } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface Template {
  id: string;
  name: string;
  type: string;
  description: string;
  lastModified: string;
  createdBy: string;
  usage: number;
  sections: number;
}

const templatesData: Template[] = [
  {
    id: 'TEMP-001',
    name: 'Enterprise Services Template',
    type: 'Enterprise',
    description: 'Comprehensive template for large enterprise service proposals',
    lastModified: '2 days ago',
    createdBy: 'Sarah Johnson',
    usage: 24,
    sections: 8
  },
  {
    id: 'TEMP-002',
    name: 'Software Implementation',
    type: 'Software',
    description: 'Standard template for software development and implementation projects',
    lastModified: '1 week ago',
    createdBy: 'Mike Chen',
    usage: 18,
    sections: 6
  },
  {
    id: 'TEMP-003',
    name: 'Consulting Services',
    type: 'Consulting',
    description: 'Template for consulting and advisory service proposals',
    lastModified: '3 days ago',
    createdBy: 'Emma Davis',
    usage: 15,
    sections: 7
  },
  {
    id: 'TEMP-004',
    name: 'Cloud Migration',
    type: 'Cloud',
    description: 'Specialized template for cloud infrastructure migration projects',
    lastModified: '5 days ago',
    createdBy: 'Alex Rodriguez',
    usage: 12,
    sections: 9
  },
  {
    id: 'TEMP-005',
    name: 'Digital Transformation',
    type: 'Digital',
    description: 'Template for comprehensive digital transformation initiatives',
    lastModified: '1 week ago',
    createdBy: 'Lisa Wang',
    usage: 8,
    sections: 10
  },
  {
    id: 'TEMP-006',
    name: 'Basic Service Agreement',
    type: 'Basic',
    description: 'Simple template for standard service agreements',
    lastModified: '2 weeks ago',
    createdBy: 'John Doe',
    usage: 31,
    sections: 4
  }
];

const typeColors = {
  'Enterprise': 'bg-[#10B981] text-white',
  'Software': 'bg-[#3B82F6] text-white',
  'Consulting': 'bg-[#F59E0B] text-white',
  'Cloud': 'bg-[#8B5CF6] text-white',
  'Digital': 'bg-[#EF4444] text-white',
  'Basic': 'bg-[#A0A0A0] text-white'
};

export function TemplatesView() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  
  const filteredTemplates = templatesData.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || template.type === selectedType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#1A1A1A]">Manage Templates</h1>
          <p className="text-[#6B7280] mt-1">Create and customize proposal templates</p>
        </div>
        
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-[#10B981] hover:bg-[#0D9F71] text-white">
              <Plus className="h-4 w-4 mr-2" />
              Create Template
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Create New Template</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="templateName">Template Name</Label>
                <Input id="templateName" placeholder="Enter template name..." />
              </div>
              <div className="space-y-2">
                <Label htmlFor="templateType">Template Type</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select template type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="enterprise">Enterprise</SelectItem>
                    <SelectItem value="software">Software</SelectItem>
                    <SelectItem value="consulting">Consulting</SelectItem>
                    <SelectItem value="cloud">Cloud</SelectItem>
                    <SelectItem value="digital">Digital</SelectItem>
                    <SelectItem value="basic">Basic</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="templateDescription">Description</Label>
                <Textarea 
                  id="templateDescription" 
                  placeholder="Describe the template purpose and usage..."
                  className="min-h-[80px]"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline">Cancel</Button>
                <Button className="bg-[#10B981] hover:bg-[#0D9F71] text-white">
                  Create Template
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#6B7280] h-4 w-4" />
          <Input
            placeholder="Search templates..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-gray-50"
          />
        </div>
        
        <Select value={selectedType} onValueChange={setSelectedType}>
          <SelectTrigger className="w-40 bg-gray-50">
            <SelectValue placeholder="All Types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="Enterprise">Enterprise</SelectItem>
            <SelectItem value="Software">Software</SelectItem>
            <SelectItem value="Consulting">Consulting</SelectItem>
            <SelectItem value="Cloud">Cloud</SelectItem>
            <SelectItem value="Digital">Digital</SelectItem>
            <SelectItem value="Basic">Basic</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTemplates.map((template) => (
          <Card key={template.id} className="border border-[#E0E0E0] shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg font-medium text-[#1A1A1A] mb-2">
                    {template.name}
                  </CardTitle>
                  <Badge className={typeColors[template.type as keyof typeof typeColors]}>
                    {template.type}
                  </Badge>
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <Copy className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-red-500 hover:text-red-700">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-[#6B7280] line-clamp-2">
                {template.description}
              </p>
              
              <div className="flex items-center justify-between text-xs text-[#6B7280]">
                <div className="flex items-center gap-1">
                  <FileText className="h-3 w-3" />
                  <span>{template.sections} sections</span>
                </div>
                <div className="flex items-center gap-1">
                  <span>{template.usage} uses</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between text-xs text-[#6B7280]">
                <div className="flex items-center gap-1">
                  <User className="h-3 w-3" />
                  <span>{template.createdBy}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  <span>{template.lastModified}</span>
                </div>
              </div>
              
              <Button className="w-full bg-[#10B981] hover:bg-[#0D9F71] text-white">
                Use Template
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Empty State */}
      {filteredTemplates.length === 0 && (
        <div className="text-center py-12">
          <FileText className="h-12 w-12 text-[#A0A0A0] mx-auto mb-4" />
          <h3 className="text-lg font-medium text-[#1A1A1A] mb-2">No templates found</h3>
          <p className="text-[#6B7280] mb-4">
            {searchTerm || selectedType !== 'all' 
              ? 'Try adjusting your search criteria or filters'
              : 'Create your first template to get started'
            }
          </p>
          {!searchTerm && selectedType === 'all' && (
            <Dialog>
              <DialogTrigger asChild>
                <Button className="bg-[#10B981] hover:bg-[#0D9F71] text-white">
                  <Plus className="h-4 w-4 mr-2" />
                  Create First Template
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Create New Template</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="templateName">Template Name</Label>
                    <Input id="templateName" placeholder="Enter template name..." />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="templateType">Template Type</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select template type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="enterprise">Enterprise</SelectItem>
                        <SelectItem value="software">Software</SelectItem>
                        <SelectItem value="consulting">Consulting</SelectItem>
                        <SelectItem value="cloud">Cloud</SelectItem>
                        <SelectItem value="digital">Digital</SelectItem>
                        <SelectItem value="basic">Basic</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="templateDescription">Description</Label>
                    <Textarea 
                      id="templateDescription" 
                      placeholder="Describe the template purpose and usage..."
                      className="min-h-[80px]"
                    />
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button variant="outline">Cancel</Button>
                    <Button className="bg-[#10B981] hover:bg-[#0D9F71] text-white">
                      Create Template
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
      )}
    </div>
  );
}