import { useState } from 'react';
import { Plus, Save, Play, Pause, ArrowRight, Users, DollarSign, Clock, Settings } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';

interface WorkflowNode {
  id: string;
  type: 'start' | 'approval' | 'condition' | 'action' | 'end';
  title: string;
  description: string;
  position: { x: number; y: number };
  conditions?: string[];
  approvers?: string[];
  automated?: boolean;
}

const workflowNodes: WorkflowNode[] = [
  {
    id: 'start',
    type: 'start',
    title: 'Proposal Created',
    description: 'New proposal submitted',
    position: { x: 50, y: 100 },
  },
  {
    id: 'value-check',
    type: 'condition',
    title: 'Value Assessment',
    description: 'Check proposal value',
    position: { x: 250, y: 100 },
    conditions: ['Value > $100,000', 'High risk client', 'Complex requirements']
  },
  {
    id: 'manager-approval',
    type: 'approval',
    title: 'Manager Approval',
    description: 'Department manager review',
    position: { x: 450, y: 50 },
    approvers: ['Sarah Johnson', 'Mike Chen', 'Emma Davis']
  },
  {
    id: 'director-approval',
    type: 'approval',
    title: 'Director Approval',
    description: 'Director-level approval required',
    position: { x: 450, y: 150 },
    approvers: ['Alex Rodriguez', 'Lisa Wang']
  },
  {
    id: 'auto-approve',
    type: 'action',
    title: 'Auto Approve',
    description: 'Automatically approve low-risk proposals',
    position: { x: 250, y: 200 },
    automated: true
  },
  {
    id: 'send-proposal',
    type: 'action',
    title: 'Send to Client',
    description: 'Deliver proposal to client',
    position: { x: 650, y: 100 },
  },
  {
    id: 'end',
    type: 'end',
    title: 'Process Complete',
    description: 'Workflow finished',
    position: { x: 850, y: 100 },
  }
];

const nodeTypeStyles = {
  start: 'bg-[#10B981] text-white border-[#10B981]',
  approval: 'bg-[#F59E0B] text-white border-[#F59E0B]',
  condition: 'bg-[#3B82F6] text-white border-[#3B82F6]',
  action: 'bg-[#8B5CF6] text-white border-[#8B5CF6]',
  end: 'bg-[#EF4444] text-white border-[#EF4444]'
};

const nodeIcons = {
  start: Play,
  approval: Users,
  condition: Settings,
  action: ArrowRight,
  end: Pause
};

export function WorkflowDesigner() {
  const [selectedNode, setSelectedNode] = useState<WorkflowNode | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#1A1A1A]">Proposal Approval Workflows</h1>
          <p className="text-[#6B7280] mt-1">Design and manage approval processes</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="outline">
            <Plus className="h-4 w-4 mr-2" />
            Add Node
          </Button>
          <Button className="bg-[#10B981] hover:bg-[#0D9F71] text-white">
            <Save className="h-4 w-4 mr-2" />
            Save Workflow
          </Button>
        </div>
      </div>

      {/* Workflow Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Canvas */}
        <div className="lg:col-span-3">
          <Card className="border border-[#E0E0E0] shadow-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-medium text-[#1A1A1A]">Workflow Canvas</CardTitle>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="bg-[#E6F4EA] text-[#10B981]">Active</Badge>
                  <Select defaultValue="default">
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="default">Default Workflow</SelectItem>
                      <SelectItem value="high-value">High-Value Workflow</SelectItem>
                      <SelectItem value="express">Express Workflow</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="relative bg-gray-50 rounded-lg p-6 min-h-[500px] overflow-x-auto">
                {/* Workflow Nodes */}
                <div className="relative">
                  {workflowNodes.map((node) => {
                    const Icon = nodeIcons[node.type];
                    return (
                      <div
                        key={node.id}
                        className={`absolute cursor-pointer transition-all hover:scale-105 ${
                          selectedNode?.id === node.id ? 'ring-2 ring-[#10B981]' : ''
                        }`}
                        style={{ 
                          left: `${node.position.x}px`, 
                          top: `${node.position.y}px` 
                        }}
                        onClick={() => setSelectedNode(node)}
                      >
                        <div className={`rounded-lg p-3 border-2 min-w-[140px] ${nodeTypeStyles[node.type]} shadow-sm`}>
                          <div className="flex items-center gap-2 mb-1">
                            <Icon className="h-4 w-4" />
                            <span className="font-medium text-sm">{node.title}</span>
                          </div>
                          <p className="text-xs opacity-90">{node.description}</p>
                          {node.automated && (
                            <Badge className="mt-2 bg-white/20 text-white text-xs">Auto</Badge>
                          )}
                        </div>
                      </div>
                    );
                  })}

                  {/* Connection Lines */}
                  <svg className="absolute inset-0 pointer-events-none" style={{ zIndex: -1 }}>
                    {/* Start to Value Check */}
                    <line x1="190" y1="115" x2="250" y2="115" stroke="#6B7280" strokeWidth="2" markerEnd="url(#arrowhead)" />
                    
                    {/* Value Check to Manager Approval */}
                    <line x1="350" y1="100" x2="450" y2="65" stroke="#6B7280" strokeWidth="2" markerEnd="url(#arrowhead)" />
                    
                    {/* Value Check to Director Approval */}
                    <line x1="350" y1="120" x2="450" y2="165" stroke="#6B7280" strokeWidth="2" markerEnd="url(#arrowhead)" />
                    
                    {/* Value Check to Auto Approve */}
                    <line x1="300" y1="150" x2="300" y2="200" stroke="#6B7280" strokeWidth="2" markerEnd="url(#arrowhead)" />
                    
                    {/* Manager Approval to Send Proposal */}
                    <line x1="590" y1="65" x2="650" y2="100" stroke="#6B7280" strokeWidth="2" markerEnd="url(#arrowhead)" />
                    
                    {/* Director Approval to Send Proposal */}
                    <line x1="590" y1="165" x2="650" y2="130" stroke="#6B7280" strokeWidth="2" markerEnd="url(#arrowhead)" />
                    
                    {/* Auto Approve to Send Proposal */}
                    <line x1="390" y1="215" x2="650" y2="130" stroke="#6B7280" strokeWidth="2" markerEnd="url(#arrowhead)" />
                    
                    {/* Send Proposal to End */}
                    <line x1="790" y1="115" x2="850" y2="115" stroke="#6B7280" strokeWidth="2" markerEnd="url(#arrowhead)" />
                    
                    <defs>
                      <marker id="arrowhead" markerWidth="10" markerHeight="7" 
                       refX="10" refY="3.5" orient="auto">
                        <polygon points="0 0, 10 3.5, 0 7" fill="#6B7280" />
                      </marker>
                    </defs>
                  </svg>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Properties Panel */}
        <div>
          <Card className="border border-[#E0E0E0] shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg font-medium text-[#1A1A1A]">
                {selectedNode ? 'Node Properties' : 'Workflow Properties'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedNode ? (
                <>
                  <div className="space-y-2">
                    <Label>Node Type</Label>
                    <div className={`px-3 py-2 rounded text-sm ${nodeTypeStyles[selectedNode.type]}`}>
                      {selectedNode.type.charAt(0).toUpperCase() + selectedNode.type.slice(1)}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="nodeTitle">Title</Label>
                    <Input 
                      id="nodeTitle"
                      value={selectedNode.title}
                      className="bg-gray-50"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="nodeDescription">Description</Label>
                    <Input 
                      id="nodeDescription"
                      value={selectedNode.description}
                      className="bg-gray-50"
                    />
                  </div>

                  {selectedNode.type === 'approval' && selectedNode.approvers && (
                    <div className="space-y-2">
                      <Label>Approvers</Label>
                      <div className="space-y-1">
                        {selectedNode.approvers.map((approver, index) => (
                          <div key={index} className="text-sm px-2 py-1 bg-gray-50 rounded">
                            {approver}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {selectedNode.type === 'condition' && selectedNode.conditions && (
                    <div className="space-y-2">
                      <Label>Conditions</Label>
                      <div className="space-y-1">
                        {selectedNode.conditions.map((condition, index) => (
                          <div key={index} className="text-sm px-2 py-1 bg-gray-50 rounded">
                            {condition}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {selectedNode.type === 'action' && (
                    <div className="flex items-center justify-between">
                      <Label htmlFor="automated">Automated</Label>
                      <Switch 
                        id="automated" 
                        checked={selectedNode.automated || false}
                      />
                    </div>
                  )}
                </>
              ) : (
                <>
                  <div className="space-y-2">
                    <Label>Workflow Statistics</Label>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-[#6B7280]">Total Nodes:</span>
                        <span className="font-medium">{workflowNodes.length}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-[#6B7280]">Approval Steps:</span>
                        <span className="font-medium">2</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-[#6B7280]">Avg. Process Time:</span>
                        <span className="font-medium">2.4 days</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-[#6B7280]">Success Rate:</span>
                        <span className="font-medium text-[#10B981]">94%</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Approval Rules</Label>
                    <div className="space-y-2 text-xs">
                      <div className="p-2 bg-blue-50 rounded border border-blue-200">
                        <div className="font-medium text-blue-900">High Value (&gt; $100k)</div>
                        <div className="text-blue-700">Requires director approval</div>
                      </div>
                      <div className="p-2 bg-yellow-50 rounded border border-yellow-200">
                        <div className="font-medium text-yellow-900">Medium Risk</div>
                        <div className="text-yellow-700">Manager approval required</div>
                      </div>
                      <div className="p-2 bg-green-50 rounded border border-green-200">
                        <div className="font-medium text-green-900">Standard (&lt; $50k)</div>
                        <div className="text-green-700">Auto-approved if low risk</div>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Workflow Templates */}
      <Card className="border border-[#E0E0E0] shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg font-medium text-[#1A1A1A]">Workflow Templates</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              {
                name: 'Standard Approval',
                description: 'Basic approval workflow for standard proposals',
                nodes: 5,
                avgTime: '1.2 days'
              },
              {
                name: 'High-Value Process',
                description: 'Enhanced workflow for high-value proposals',
                nodes: 7,
                avgTime: '3.5 days'
              },
              {
                name: 'Express Workflow',
                description: 'Fast-track process for urgent proposals',
                nodes: 3,
                avgTime: '4 hours'
              }
            ].map((template, index) => (
              <div key={index} className="p-4 border border-[#E0E0E0] rounded-lg hover:shadow-sm transition-shadow">
                <h3 className="font-medium text-[#1A1A1A] mb-1">{template.name}</h3>
                <p className="text-sm text-[#6B7280] mb-3">{template.description}</p>
                <div className="flex justify-between items-center text-xs text-[#6B7280]">
                  <span>{template.nodes} nodes</span>
                  <span>~{template.avgTime}</span>
                </div>
                <Button variant="outline" className="w-full mt-3" size="sm">
                  Use Template
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}