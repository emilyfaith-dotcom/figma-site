import { Download, FileText } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

export function ProposalPreview() {
  return (
    <Card className="bg-white shadow-sm border border-gray-200 rounded-lg">
      <CardHeader className="pb-4">
        <CardTitle className="text-[#1A1A1A] font-medium">Preview Proposal</CardTitle>
      </CardHeader>
      <CardContent>
        {/* Placeholder for PDF Preview */}
        <div className="bg-[#F8F9FA] border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
          <div className="flex flex-col items-center gap-4">
            <FileText className="h-12 w-12 text-[#6B7280]" />
            <div className="space-y-2">
              <p className="text-[#6B7280] font-medium">No proposal generated yet</p>
              <p className="text-sm text-[#6B7280]">Generate a proposal to see preview here</p>
            </div>
          </div>
        </div>
        
        {/* Download Button */}
        <Button 
          variant="outline" 
          className="w-full mt-4 border-[#0A9D58] text-[#0A9D58] hover:bg-[#E6F4EA]"
          disabled
        >
          <Download className="h-4 w-4 mr-2" />
          Download PDF
        </Button>
      </CardContent>
    </Card>
  );
}