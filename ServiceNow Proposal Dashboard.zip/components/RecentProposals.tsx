import { Edit, Eye } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';

const proposalsData: Array<{
  id: string;
  client: string;
  status: ProposalStatus;
  createdDate: string;
}> = [
  {
    id: 'PROP-2024-001',
    client: 'Acme Corporation',
    status: 'Draft',
    createdDate: 'Jan 15, 2024',
  },
  {
    id: 'PROP-2024-002',
    client: 'TechFlow Solutions',
    status: 'Sent',
    createdDate: 'Jan 12, 2024',
  },
  {
    id: 'PROP-2024-003',
    client: 'Global Enterprises',
    status: 'Approved',
    createdDate: 'Jan 10, 2024',
  },
  {
    id: 'PROP-2024-004',
    client: 'Innovation Labs',
    status: 'Draft',
    createdDate: 'Jan 08, 2024',
  },
  {
    id: 'PROP-2024-005',
    client: 'Digital Dynamics',
    status: 'Sent',
    createdDate: 'Jan 05, 2024',
  },
];

type ProposalStatus = 'Draft' | 'Sent' | 'Approved';

function getStatusBadge(status: ProposalStatus) {
  const statusConfig: Record<ProposalStatus, { color: string; label: string }> = {
    Draft: { color: 'bg-[#B0B0B0] text-white', label: 'Draft' },
    Sent: { color: 'bg-[#007BFF] text-white', label: 'Sent' },
    Approved: { color: 'bg-[#0A9D58] text-white', label: 'Approved' },
  };
  
  const config = statusConfig[status] || statusConfig.Draft;
  
  return (
    <Badge className={`${config.color} hover:${config.color} font-medium`}>
      {config.label}
    </Badge>
  );
}

export function RecentProposals() {
  return (
    <Card className="bg-white shadow-sm border border-gray-200 rounded-lg">
      <CardHeader className="pb-4">
        <CardTitle className="text-[#1A1A1A] font-medium">Recent Proposals</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow className="bg-[#F8F9FA] border-b">
              <TableHead className="text-[#6B7280] font-medium px-6 py-4">Proposal ID</TableHead>
              <TableHead className="text-[#6B7280] font-medium px-6 py-4">Client Name</TableHead>
              <TableHead className="text-[#6B7280] font-medium px-6 py-4">Status</TableHead>
              <TableHead className="text-[#6B7280] font-medium px-6 py-4">Created Date</TableHead>
              <TableHead className="text-[#6B7280] font-medium px-6 py-4">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {proposalsData.map((proposal) => (
              <TableRow key={proposal.id} className="border-b hover:bg-[#F8F9FA]">
                <TableCell className="px-6 py-4 text-[#1A1A1A] font-medium">
                  {proposal.id}
                </TableCell>
                <TableCell className="px-6 py-4 text-[#1A1A1A]">
                  {proposal.client}
                </TableCell>
                <TableCell className="px-6 py-4">
                  {getStatusBadge(proposal.status)}
                </TableCell>
                <TableCell className="px-6 py-4 text-[#6B7280]">
                  {proposal.createdDate}
                </TableCell>
                <TableCell className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-[#6B7280] hover:text-[#0A9D58] hover:bg-[#E6F4EA]"
                      aria-label={`View proposal ${proposal.id}`}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-[#6B7280] hover:text-[#0A9D58] hover:bg-[#E6F4EA]"
                      aria-label={`Edit proposal ${proposal.id}`}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}