import { TrendingUp, Users, Clock, DollarSign, Calendar, FileText } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';

const proposalTrendData = [
  { month: 'Jan', total: 24, approved: 18, sent: 20 },
  { month: 'Feb', total: 32, approved: 25, sent: 28 },
  { month: 'Mar', total: 28, approved: 22, sent: 25 },
  { month: 'Apr', total: 40, approved: 35, sent: 38 },
  { month: 'May', total: 45, approved: 38, sent: 42 },
  { month: 'Jun', total: 52, approved: 45, sent: 48 },
];

const statusDistribution = [
  { name: 'Approved', value: 45, color: '#10B981' },
  { name: 'In Review', value: 25, color: '#F59E0B' },
  { name: 'Draft', value: 20, color: '#A0A0A0' },
  { name: 'Sent', value: 10, color: '#3B82F6' },
];

export function DashboardView() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#1A1A1A]">Proposal Analytics Dashboard</h1>
          <p className="text-[#6B7280] mt-1">Track your proposal performance and metrics</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Select defaultValue="30days">
            <SelectTrigger className="w-36">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 days</SelectItem>
              <SelectItem value="30days">Last 30 days</SelectItem>
              <SelectItem value="90days">Last 90 days</SelectItem>
              <SelectItem value="1year">Last year</SelectItem>
            </SelectContent>
          </Select>
          
          <Select defaultValue="all">
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Users</SelectItem>
              <SelectItem value="me">My Proposals</SelectItem>
              <SelectItem value="team">Team Only</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border border-[#E0E0E0] shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#6B7280]">Total Proposals</CardTitle>
            <FileText className="h-4 w-4 text-[#10B981]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#1A1A1A]">145</div>
            <p className="text-xs text-[#10B981] mt-1">
              <TrendingUp className="inline h-3 w-3 mr-1" />
              +12% from last month
            </p>
          </CardContent>
        </Card>

        <Card className="border border-[#E0E0E0] shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#6B7280]">Conversion Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-[#10B981]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#1A1A1A]">78.2%</div>
            <p className="text-xs text-[#10B981] mt-1">
              <TrendingUp className="inline h-3 w-3 mr-1" />
              +5.1% from last month
            </p>
          </CardContent>
        </Card>

        <Card className="border border-[#E0E0E0] shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#6B7280]">Avg. Approval Time</CardTitle>
            <Clock className="h-4 w-4 text-[#F59E0B]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#1A1A1A]">2.4 days</div>
            <p className="text-xs text-[#10B981] mt-1">
              <TrendingUp className="inline h-3 w-3 mr-1" />
              -0.8 days improvement
            </p>
          </CardContent>
        </Card>

        <Card className="border border-[#E0E0E0] shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#6B7280]">Total Value</CardTitle>
            <DollarSign className="h-4 w-4 text-[#10B981]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#1A1A1A]">$2.4M</div>
            <p className="text-xs text-[#10B981] mt-1">
              <TrendingUp className="inline h-3 w-3 mr-1" />
              +18% from last month
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Proposal Trends */}
        <Card className="border border-[#E0E0E0] shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-medium text-[#1A1A1A]">Proposal Trends</CardTitle>
            <p className="text-sm text-[#6B7280]">Monthly proposal activity over time</p>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={proposalTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="month" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" />
                  <Tooltip />
                  <Line type="monotone" dataKey="total" stroke="#10B981" strokeWidth={2} name="Total" />
                  <Line type="monotone" dataKey="approved" stroke="#3B82F6" strokeWidth={2} name="Approved" />
                  <Line type="monotone" dataKey="sent" stroke="#F59E0B" strokeWidth={2} name="Sent" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Status Distribution */}
        <Card className="border border-[#E0E0E0] shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-medium text-[#1A1A1A]">Status Distribution</CardTitle>
            <p className="text-sm text-[#6B7280]">Current proposal status breakdown</p>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="border border-[#E0E0E0] shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg font-medium text-[#1A1A1A]">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { action: 'Proposal PROP-2024-089 approved by Sarah Johnson', time: '2 hours ago', type: 'approved' },
              { action: 'New proposal created for TechFlow Solutions', time: '4 hours ago', type: 'created' },
              { action: 'Proposal PROP-2024-087 sent to client for review', time: '6 hours ago', type: 'sent' },
              { action: 'Template "Enterprise Services" updated', time: '1 day ago', type: 'updated' },
              { action: 'Proposal PROP-2024-085 signed by Acme Corporation', time: '2 days ago', type: 'signed' },
            ].map((activity, index) => (
              <div key={index} className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                <div className={`w-2 h-2 rounded-full ${
                  activity.type === 'approved' ? 'bg-[#10B981]' :
                  activity.type === 'created' ? 'bg-[#3B82F6]' :
                  activity.type === 'sent' ? 'bg-[#F59E0B]' :
                  activity.type === 'updated' ? 'bg-[#A0A0A0]' :
                  'bg-[#10B981]'
                }`} />
                <div className="flex-1">
                  <p className="text-sm text-[#1A1A1A]">{activity.action}</p>
                  <p className="text-xs text-[#6B7280]">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}