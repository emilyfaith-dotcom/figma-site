import { useState } from 'react';
import { Users, Shield, Bell, Database, Key, Globe, Save } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';

interface UserRole {
  id: string;
  name: string;
  email: string;
  role: 'Admin' | 'Manager' | 'User' | 'Viewer';
  permissions: {
    create: boolean;
    edit: boolean;
    approve: boolean;
    send: boolean;
    delete: boolean;
  };
  lastActive: string;
  status: 'Active' | 'Inactive';
}

const usersData: UserRole[] = [
  {
    id: '1',
    name: 'John Doe',
    email: 'john.doe@company.com',
    role: 'Admin',
    permissions: { create: true, edit: true, approve: true, send: true, delete: true },
    lastActive: '2 hours ago',
    status: 'Active'
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    email: 'sarah.johnson@company.com',
    role: 'Manager',
    permissions: { create: true, edit: true, approve: true, send: true, delete: false },
    lastActive: '1 day ago',
    status: 'Active'
  },
  {
    id: '3',
    name: 'Mike Chen',
    email: 'mike.chen@company.com',
    role: 'User',
    permissions: { create: true, edit: true, approve: false, send: false, delete: false },
    lastActive: '3 hours ago',
    status: 'Active'
  },
  {
    id: '4',
    name: 'Emma Davis',
    email: 'emma.davis@company.com',
    role: 'Viewer',
    permissions: { create: false, edit: false, approve: false, send: false, delete: false },
    lastActive: '1 week ago',
    status: 'Inactive'
  }
];

const roleColors = {
  'Admin': 'bg-[#EF4444] text-white',
  'Manager': 'bg-[#F59E0B] text-white',
  'User': 'bg-[#10B981] text-white',
  'Viewer': 'bg-[#A0A0A0] text-white'
};

export function SettingsView() {
  const [activeTab, setActiveTab] = useState('users');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#1A1A1A]">Settings</h1>
          <p className="text-[#6B7280] mt-1">Manage system configuration and user permissions</p>
        </div>
        
        <Button className="bg-[#10B981] hover:bg-[#0D9F71] text-white">
          <Save className="h-4 w-4 mr-2" />
          Save Changes
        </Button>
      </div>

      {/* Settings Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="users" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Users & Roles
          </TabsTrigger>
          <TabsTrigger value="permissions" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Permissions
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="integrations" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            Integrations
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Key className="h-4 w-4" />
            Security
          </TabsTrigger>
        </TabsList>

        {/* Users & Roles Tab */}
        <TabsContent value="users" className="space-y-4">
          <Card className="border border-[#E0E0E0] shadow-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-medium text-[#1A1A1A]">User Management</CardTitle>
                <Button className="bg-[#10B981] hover:bg-[#0D9F71] text-white">
                  Add User
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Active</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {usersData.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{user.name}</div>
                          <div className="text-sm text-[#6B7280]">{user.email}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={roleColors[user.role]}>
                          {user.role}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.status === 'Active' ? 'default' : 'secondary'}>
                          {user.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-[#6B7280]">{user.lastActive}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">Edit</Button>
                          <Button variant="outline" size="sm" className="text-red-600">
                            Remove
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Permissions Tab */}
        <TabsContent value="permissions" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Object.keys(roleColors).map((role) => (
              <Card key={role} className="border border-[#E0E0E0] shadow-sm">
                <CardHeader>
                  <CardTitle className="text-lg font-medium text-[#1A1A1A] flex items-center gap-2">
                    <Badge className={roleColors[role as keyof typeof roleColors]}>
                      {role}
                    </Badge>
                    Role Permissions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    { key: 'create', label: 'Create Proposals', description: 'Can create new proposals' },
                    { key: 'edit', label: 'Edit Proposals', description: 'Can modify existing proposals' },
                    { key: 'approve', label: 'Approve Proposals', description: 'Can approve proposals for sending' },
                    { key: 'send', label: 'Send Proposals', description: 'Can send proposals to clients' },
                    { key: 'delete', label: 'Delete Proposals', description: 'Can delete proposals (admin only)' }
                  ].map((permission) => (
                    <div key={permission.key} className="flex items-center justify-between">
                      <div>
                        <Label className="font-medium">{permission.label}</Label>
                        <p className="text-sm text-[#6B7280]">{permission.description}</p>
                      </div>
                      <Switch 
                        checked={role === 'Admin' || 
                          (role === 'Manager' && permission.key !== 'delete') ||
                          (role === 'User' && ['create', 'edit'].includes(permission.key)) ||
                          (role === 'Viewer' && false)
                        }
                      />
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="border border-[#E0E0E0] shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-medium text-[#1A1A1A]">Email Notifications</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { label: 'Proposal Created', description: 'When a new proposal is created', enabled: true },
                  { label: 'Approval Required', description: 'When approval is needed', enabled: true },
                  { label: 'Proposal Approved', description: 'When a proposal is approved', enabled: true },
                  { label: 'Proposal Sent', description: 'When a proposal is sent to client', enabled: false },
                  { label: 'Client Response', description: 'When client responds to proposal', enabled: true }
                ].map((notification, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div>
                      <Label className="font-medium">{notification.label}</Label>
                      <p className="text-sm text-[#6B7280]">{notification.description}</p>
                    </div>
                    <Switch defaultChecked={notification.enabled} />
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="border border-[#E0E0E0] shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-medium text-[#1A1A1A]">System Alerts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { label: 'Workflow Failures', description: 'Alert when workflows fail', enabled: true },
                  { label: 'Performance Issues', description: 'System performance alerts', enabled: true },
                  { label: 'Security Events', description: 'Security-related notifications', enabled: true },
                  { label: 'Data Backup Status', description: 'Backup completion notifications', enabled: false },
                  { label: 'Integration Errors', description: 'Third-party integration issues', enabled: true }
                ].map((alert, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div>
                      <Label className="font-medium">{alert.label}</Label>
                      <p className="text-sm text-[#6B7280]">{alert.description}</p>
                    </div>
                    <Switch defaultChecked={alert.enabled} />
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Integrations Tab */}
        <TabsContent value="integrations" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              {
                name: 'DocuSign',
                description: 'E-signature integration for proposals',
                status: 'Connected',
                icon: '📝',
                lastSync: '2 hours ago'
              },
              {
                name: 'Salesforce CRM',
                description: 'Customer data synchronization',
                status: 'Connected',
                icon: '👥',
                lastSync: '30 minutes ago'
              },
              {
                name: 'Adobe Sign',
                description: 'Alternative e-signature solution',
                status: 'Not Connected',
                icon: '✍️',
                lastSync: 'Never'
              },
              {
                name: 'Microsoft Dynamics',
                description: 'ERP system integration',
                status: 'Not Connected',
                icon: '📊',
                lastSync: 'Never'
              }
            ].map((integration, index) => (
              <Card key={index} className="border border-[#E0E0E0] shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{integration.icon}</span>
                      <div>
                        <h3 className="font-medium text-[#1A1A1A]">{integration.name}</h3>
                        <p className="text-sm text-[#6B7280]">{integration.description}</p>
                      </div>
                    </div>
                    <Badge 
                      className={integration.status === 'Connected' ? 
                        'bg-[#10B981] text-white' : 
                        'bg-[#A0A0A0] text-white'
                      }
                    >
                      {integration.status}
                    </Badge>
                  </div>
                  
                  <div className="text-xs text-[#6B7280] mb-4">
                    Last sync: {integration.lastSync}
                  </div>
                  
                  <Button 
                    variant={integration.status === 'Connected' ? 'outline' : 'default'}
                    className={integration.status === 'Not Connected' ? 
                      'bg-[#10B981] hover:bg-[#0D9F71] text-white w-full' : 
                      'w-full'
                    }
                  >
                    {integration.status === 'Connected' ? 'Configure' : 'Connect'}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="border border-[#E0E0E0] shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-medium text-[#1A1A1A]">Authentication</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="font-medium">Two-Factor Authentication</Label>
                    <p className="text-sm text-[#6B7280]">Require 2FA for all users</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="font-medium">SSO Integration</Label>
                    <p className="text-sm text-[#6B7280]">Enable single sign-on</p>
                  </div>
                  <Switch defaultChecked={false} />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="sessionTimeout">Session Timeout (minutes)</Label>
                  <Select defaultValue="60">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="60">60 minutes</SelectItem>
                      <SelectItem value="120">2 hours</SelectItem>
                      <SelectItem value="480">8 hours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card className="border border-[#E0E0E0] shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-medium text-[#1A1A1A]">Data Protection</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="font-medium">Encryption at Rest</Label>
                    <p className="text-sm text-[#6B7280]">Encrypt stored data</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="font-medium">Audit Logging</Label>
                    <p className="text-sm text-[#6B7280]">Log all user actions</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="backupFrequency">Backup Frequency</Label>
                  <Select defaultValue="daily">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hourly">Hourly</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card className="border border-[#E0E0E0] shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg font-medium text-[#1A1A1A]">Recent Security Events</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { event: 'User login from new location', user: 'john.doe@company.com', time: '2 hours ago', severity: 'Medium' },
                  { event: 'Failed login attempt', user: 'unknown@external.com', time: '1 day ago', severity: 'High' },
                  { event: 'Password reset requested', user: 'sarah.johnson@company.com', time: '2 days ago', severity: 'Low' },
                  { event: 'API key regenerated', user: 'system', time: '1 week ago', severity: 'Medium' }
                ].map((event, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-sm">{event.event}</p>
                      <p className="text-xs text-[#6B7280]">{event.user} • {event.time}</p>
                    </div>
                    <Badge 
                      className={
                        event.severity === 'High' ? 'bg-[#EF4444] text-white' :
                        event.severity === 'Medium' ? 'bg-[#F59E0B] text-white' :
                        'bg-[#10B981] text-white'
                      }
                    >
                      {event.severity}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}